An archive the viewer offers to download.
